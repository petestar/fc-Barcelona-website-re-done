<footer class="bg-basecolor footer">
	<section class="container">
		<div class="row">
			<div class="col-12 col-md-3 mb-4">
				<h4 class="text-white">Goalkeepers</h4>
				<ul class="text-white">
					<li>Marc-André ter Stegen</li>
					<li>Norberto Murara Neto</li>
				</ul>
			</div>
			<div class="col-12 col-md-3 mb-4">
				<h4 class="text-white">Defenders</h4>
				<ul class="text-white">
					<li>Sergiño Dest</li>
					<li>Gerard Piqué</li>
					<li>Clément Lenglet</li>
					<li>Ronald Araújo</li>
					<li>Jordi Alba</li>
					<li>Sergi Roberto</li>
					<li>Samuel Umtiti</li>
					<li>Júnior Firpo</li>
				</ul>
			</div>
			<div class="col-12 col-md-3 mb-4">
				<h4 class="text-white">Midfielders</h4>
				<ul class="text-white">
					<li>Sergio Busquets</li>
					<li>Miralem Pjanic</li>
					<li>Ricard Puig</li>
					<li>Philippe Coutinho</li>
					<li>Pedri</li>
					<li>Matheus Fernandes</li>
					<li>Frenkie de Jong</li>
				</ul>
			</div>
			<div class="col-12 col-md-3 mb-4">
				<h4 class="text-white">Forwards</h4>
				<ul class="text-white">
					<li>Antoine Griezmann</li>
					<li>Martin Braithwaite</li>
					<li>Lionel Messi</li>
					<li>Ousmane Dembélé</li>
					<li>Trincão</li>
					<li>Anssumane Fati</li>
				</ul>
			</div>
		</div>
	</section>
</footer>