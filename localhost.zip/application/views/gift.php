<main class="about-main">
	<section class="container">
		<div class="row">
			<div class="col-12 mb-4">
				<h1 class="text-dark">Drap and Drop Your Choice FC Barcelona Jersey</h1>
				<p class="text-muted mb-3">For all culers and fans whose support and enthusiasm can never stop to encourage our ever striving players from post to post.</p>
				<!-- 3 -->
				<form action="<?= base_url(); ?>gift/upload" class="dropzone" enctype="multipart/form-data" id="upload-form">
				</form>
			</div>
		</div>
	</section>
</main>